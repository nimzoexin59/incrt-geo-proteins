# Setup instructions for the `incrt-geo-proteins` GitHub repository

This guide walks through creating the GitHub organisation, the repository, and uploading the package contents. **Everything is done through the GitHub web interface — no command line / no `git` needed.**

Estimated time: **20 minutes**.

---

## Step 1 — Create the GitHub organisation `exin-lti-upjv`

If the organisation already exists, skip to Step 2.

1. Sign in to https://github.com (create a free GitHub account if you don't have one)
2. Click your avatar (top-right) → **Your organizations** → **New organization**
3. Choose the **Free plan**
4. **Organization account name:** `exin-lti-upjv`
5. **Contact email:** `giansalvo.cirrincione@u-picardie.fr`
6. **This organization belongs to:** A business or institution
7. Skip the "Invite members" step (you can add Marta later)
8. Skip the survey

Now you are at `https://github.com/exin-lti-upjv`.

---

## Step 2 — Create the empty repository

1. From the org page, click **New repository** (green button, top right)
2. **Repository name:** `incrt-geo-proteins`
3. **Description:** *Self-architecting protein transformers — code and pretrained checkpoints for the paper "Self-Architecting Protein Transformers: An Empirical Study"*
4. **Visibility:** Public
5. **Do NOT** initialize with a README — we'll upload our own
6. **Do NOT** add a `.gitignore` — we'll upload our own
7. **Do NOT** choose a license — we'll upload our own
8. Click **Create repository**

You now have an empty repo at `https://github.com/exin-lti-upjv/incrt-geo-proteins`.

---

## Step 3 — Upload the package contents

You'll see a screen with a section *"…or upload an existing file"* — click on **"uploading an existing file"** (it's a hyperlink).

You'll be on the upload page. Drag-and-drop **all files and folders** from the package zip into the upload area:

- `README.md`
- `LICENSE`
- `CITATION.cff`
- `requirements.txt`
- `.gitignore`
- `data/` *(folder, with the `README.md` inside)*
- `notebooks/` *(folder)*
- `scripts/` *(folder)*

**For folders:** drag the entire folder (not its contents). GitHub preserves the folder structure.

**Commit message:** *Initial commit: paper code, notebooks, and documentation*

Click **Commit changes**.

That's it — the repository is now populated.

---

## Step 4 — Add the actual notebooks

The package zip ships with the `notebooks/` and `scripts/` folders **empty** (because notebook files are typically large and you may want to clean them before publishing). After Step 3, repeat the upload process for these directories:

1. From the repo home, click **Add file** → **Upload files**
2. Navigate into the `notebooks/` folder (you can drag files into a specific folder via the URL bar: `github.com/exin-lti-upjv/incrt-geo-proteins/upload/main/notebooks`)
3. Upload each notebook from your local copies on Google Drive:
   - `incrt_geo_v8.ipynb`
   - `incrt_geo_v9.ipynb`
   - `incrt_geo_v10.ipynb`
   - `incrt_geo_v11.ipynb`
   - `incrt_geo_v9_multivertebrate.ipynb`

4. Repeat for `scripts/`:
   - `allnight_eval.ipynb`
   - `v9p_pfam_rescue.ipynb`

**Tip — clean output cells before uploading:**
Open each notebook in Colab → **Edit → Clear all outputs** → File → Download (.ipynb). Smaller files, no proprietary paths in cell outputs, cleaner repo.

---

## Step 5 — Add Marta as collaborator

1. From the repo home, click **Settings** (top right of repo)
2. Left sidebar: **Collaborators and teams**
3. Click **Add people**
4. Enter Marta's GitHub username (or her email if known)
5. Select role: **Maintain** (can manage issues, releases, branches, but not delete the repo)
6. Send invitation

Marta will receive an email and can accept whenever.

---

## Step 6 — Verify the repo looks professional

Visit `https://github.com/exin-lti-upjv/incrt-geo-proteins`. You should see:

- ✅ A green "Apache-2.0 license" badge top right
- ✅ The README rendered with shields, headline result table, structure tree
- ✅ A **Cite this repository** button (right sidebar) populated by `CITATION.cff`
- ✅ A clean folder structure with `data/`, `notebooks/`, `scripts/`

If you see all four ✅, the repo is **submission-ready** and you can put the URL `https://github.com/exin-lti-upjv/incrt-geo-proteins` in the paper's "Code Availability" section.

---

## Step 7 — After paper acceptance: tag a release

When the paper is accepted, create a permanent versioned snapshot:

1. From repo home → **Releases** (right sidebar) → **Create a new release**
2. **Tag:** `v1.0.0`
3. **Release title:** *Paper version: Cirrincione & Lovino, Briefings in Bioinformatics, 2026*
4. **Description:** *Code accompanying the published paper. See README for full details.*
5. Click **Publish release**

GitHub auto-archives this version with a permanent zip download. Zenodo can be configured to mint a DOI for each release (see [ZENODO_INSTRUCTIONS.md](ZENODO_INSTRUCTIONS.md)).

---

## Troubleshooting

**"My upload exceeded 100 MB"** — Large files (`.pt` checkpoints) cannot live in GitHub. They must go on Zenodo (see ZENODO_INSTRUCTIONS.md) and be **linked** from the README. The `.gitignore` we ship already excludes `.pt`/`.pth`/`.ckpt` files.

**"GitHub says my organisation name is taken"** — `exin-lti-upjv` may have been registered. Try `exin-lti` or `exinlab-upjv` and update the URL in `README.md`, `CITATION.cff` accordingly.

**"Marta cannot accept the invitation"** — She needs a free GitHub account first. Free accounts allow unlimited public-repo collaboration.
