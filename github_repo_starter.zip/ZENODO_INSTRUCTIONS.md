# Zenodo upload instructions for pretrained checkpoints

The pretrained `.pt` checkpoints (5 files, ~570 MB total) cannot be hosted on GitHub (100 MB per-file limit). The standard practice in scientific publishing is to host them on **Zenodo**, which provides a permanent DOI and 50 GB free storage.

This guide covers upload, metadata, DOI assignment, and updating the README/paper to reference the DOI.

Estimated time: **15 minutes**.

---

## Step 1 — Sign in to Zenodo

1. Go to https://zenodo.org
2. Click **Sign up / Log in** (top right)
3. **Best practice:** sign in with your **ORCID** (`0000-0002-2894-6691`). This automatically links your Zenodo account to your ORCID profile and to your published papers.
4. Alternative: use your institutional email.

---

## Step 2 — Create a new upload

1. From your Zenodo dashboard, click **+ New upload** (top right green button)
2. **Files:** drag-and-drop all five checkpoints:
   - `incrt_geo_v8.pt`
   - `incrt_geo_v9.pt`
   - `incrt_geo_v10.pt`
   - `incrt_geo_v11.pt`
   - `incrt_geo_v9p.pt`
3. Tip: also upload a small `MANIFEST.json` file with checkpoint metadata (params, layer count, accuracy) for convenience. Example content:

```json
{
  "v8":  {"params": 37500000, "n_layers": 2, "n_heads_per_layer": [290, 218], "tokeniser": "3-mer",
          "pretraining_corpus": "human_ensembl_115", "pfam50_probe_acc": 0.6358, "pfam50_ft_acc": 0.5810},
  "v9":  {"params": 22700000, "n_layers": 4, "n_heads_per_layer": [207, 135, 1, 1], "tokeniser": "1-mer",
          "pretraining_corpus": "human_ensembl_115", "pfam50_probe_acc": 0.7603, "pfam50_ft_acc": 0.7078},
  "v10": {"params": 14200000, "n_layers": 1, "n_heads_per_layer": [215], "ablation": "Level-3 disabled",
          "pretraining_corpus": "human_ensembl_115", "pfam50_probe_acc": 0.6998, "pfam50_ft_acc": 0.6301},
  "v11": {"params": 15100000, "n_layers": 1, "n_heads_per_layer": [228], "ablation": "alpha-loss disabled",
          "pretraining_corpus": "human_ensembl_115", "pfam50_probe_acc": 0.6747, "pfam50_ft_acc": 0.6347},
  "v9p": {"params": 49400000, "n_layers": 6, "n_heads_per_layer": [241, 172, 117, 103, 69, 50],
          "pretraining_corpus": "ensembl_multi_vertebrate_8species",
          "pfam50_probe_acc": 0.5594, "pfam50_ft_acc": 0.6358}
}
```

---

## Step 3 — Fill in the metadata form

| Field | Value |
|-------|-------|
| **Resource type** | Dataset |
| **Title** | INCRT-geo: pretrained protein transformer checkpoints (v8, v9, v10, v11, v9') |
| **Authors** | Cirrincione, Giansalvo (UPJV); Lovino, Marta (UniMoRe) — both with ORCID |
| **Description** | Five pretrained INCRT-geo (self-architecting transformer) checkpoints for protein language modelling, accompanying the paper *"Self-Architecting Protein Transformers: An Empirical Study"* (Cirrincione & Lovino, Briefings in Bioinformatics 2026, under review). Includes the main model (v9), three ablations (v8, v10, v11), and a multi-vertebrate scaling experiment (v9'). All checkpoints are PyTorch state-dicts compatible with the code at https://github.com/exin-lti-upjv/incrt-geo-proteins. |
| **Keywords** | `protein language models`, `self-architecting transformers`, `pretrained models`, `Pfam classification`, `human proteome`, `INCRT-geo` |
| **License** | Apache 2.0 (matches the code repository) |
| **Funding** | *(if applicable, link UPJV / UniMoRe grants)* |
| **Related identifiers** | Add the GitHub repo URL with relation type **"is supplemented by"** |

---

## Step 4 — Reserve a DOI before publishing

In the metadata form, click **Reserve DOI**. Zenodo gives you a DOI immediately, like `10.5281/zenodo.13456789`, even before the upload is finalised.

**This is important:** put this DOI in the paper's "Data Availability" section *before* submission. Reviewers can verify the DOI resolves to the upload landing page even in pre-publication state.

---

## Step 5 — Save as draft, then publish at submission

- Click **Save** to keep it as a draft (not yet world-visible)
- Verify everything looks correct on the preview page
- When ready to submit the paper to Briefings, click **Publish**

After publishing, the upload is **immutable**: you cannot modify files. If you need to update (e.g., a corrected checkpoint), Zenodo creates a new version with a new DOI; the old DOI continues to resolve to the original version. This is intentional — it guarantees citation stability.

---

## Step 6 — Update the README and paper

Once you have the DOI (e.g., `10.5281/zenodo.13456789`):

1. **README.md** — replace the placeholder line:
   ```
   Zenodo DOI: 10.5281/zenodo.XXXXXXX (placeholder ...)
   ```
   with:
   ```
   Zenodo DOI: 10.5281/zenodo.13456789
   ```
   And add a Zenodo badge near the top:
   ```markdown
   [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.13456789.svg)](https://doi.org/10.5281/zenodo.13456789)
   ```

2. **CITATION.cff** — add the dataset DOI as a related identifier (optional)

3. **Paper Data Availability section** — write something like:
   > *"Pretrained checkpoints (v8, v9, v10, v11, v9') are archived on Zenodo with DOI [10.5281/zenodo.13456789](https://doi.org/10.5281/zenodo.13456789). Source code, evaluation pipelines, and raw result files are available at https://github.com/exin-lti-upjv/incrt-geo-proteins under the Apache 2.0 licence."*

---

## Step 7 — Optional: GitHub-Zenodo automatic linking

For each future GitHub release, Zenodo can automatically mint a fresh DOI without manual upload. This is the gold standard for software reproducibility.

1. Sign in to https://zenodo.org/account/settings/github/
2. Authorise Zenodo to access your GitHub
3. Find `exin-lti-upjv/incrt-geo-proteins` in the list of repos and **toggle ON**
4. Now whenever you create a GitHub release (e.g., `v1.0.0`), Zenodo automatically:
   - Downloads the release zip
   - Mints a DOI
   - Updates the "all versions" DOI to point to the latest

This is most useful **after** the paper is published, when you want to keep the code archive in sync with bug-fixes and improvements.

---

## Troubleshooting

**"My checkpoints are too large for my Zenodo upload limit"** — Default Zenodo limit per upload is 50 GB; checkpoints together are <1 GB, so well within limits. If you genuinely have larger files, contact Zenodo support; they often grant exceptions for scientific data.

**"I want to keep the upload private until paper acceptance"** — Zenodo allows **restricted access** during draft state. The DOI is reserved, but the files are not publicly downloadable until you click Publish. This is the recommended workflow during peer review.

**"Can I update the checkpoints later?"** — Yes, via Zenodo's **versioning** feature: from the existing record landing page, click "New version", upload modified files, publish. Each version gets its own DOI; an "all versions" DOI always points to the latest.
