# Data

The pretraining and evaluation pipelines download all input data from public sources at runtime. **Nothing in this directory needs to be pre-populated.** This directory is created automatically the first time a notebook is run, and the FASTA / TSV files are cached here for future runs.

## Sources

| File | Source | Used by |
|------|--------|---------|
| `human_pep.fa.gz` | [Ensembl release 115 — Homo sapiens GRCh38 pep.all](https://ftp.ensembl.org/pub/release-115/fasta/homo_sapiens/pep/Homo_sapiens.GRCh38.pep.all.fa.gz) | All v8/v9/v10/v11 pretraining + Pfam evaluation |
| `multi_vertebrate_proteins.json` | Eight vertebrate proteomes from Ensembl release 115 (homo_sapiens, macaca_mulatta, mus_musculus, rattus_norvegicus, bos_taurus, gallus_gallus, xenopus_tropicalis, danio_rerio); see `notebooks/incrt_geo_v9_multivertebrate.ipynb` for the exact filtering procedure | v9' multi-vertebrate pretraining |
| `human_uniprot_pfam.tsv` | UniProt REST API: human proteins with Pfam cross-references, fields: `accession`, `xref_pfam`, `xref_ensembl`, `gene_names` | Pfam-50 evaluation |

## Filtering

For all corpora, sequences are filtered as follows:
- length ∈ [10, 510] amino acids (510 = 512 − 2 for `[CLS]` / `[SEP]` tokens)
- no non-standard residues (X, B, Z, U, O, *)

For the multi-vertebrate corpus, sequences are additionally **deduplicated by exact sequence string** (so an identical protein shared between two species is kept only once).

## Reproducibility

The notebooks pin Ensembl release 115 explicitly. UniProt data are continuously updated; the versions used in the paper were retrieved between April and May 2026. Re-running the pipeline today may produce slightly different Pfam dataset sizes if UniProt has added or removed annotations in the interim.
