# Pretraining notebooks

This directory hosts the five Jupyter notebooks that produce the pretrained INCRT-geo checkpoints used in the paper. **Each notebook is end-to-end:** download data → tokeniser → pretraining → save checkpoint → Pfam evaluation.

| Notebook | Description | Pretraining time on Colab Pro+ A100 |
|----------|-------------|--------------------------------------|
| `incrt_geo_v8.ipynb` | 3-mer tokeniser baseline (full INCRT-geo on human proteome) | ~3 hours |
| `incrt_geo_v9.ipynb` | **Main model:** 1-mer tokeniser, full INCRT-geo, human proteome | ~3 hours |
| `incrt_geo_v10.ipynb` | Ablation: Level-3 (depth growth) disabled | ~2 hours |
| `incrt_geo_v11.ipynb` | Ablation: alpha-loss disabled | ~2 hours |
| `incrt_geo_v9_multivertebrate.ipynb` | Scaling experiment: 8-species vertebrate corpus (~284k seqs), early-stopped at epoch 2 | ~10 hours (2 epochs) |

## How to upload

The package zip ships this directory **empty**. Upload your local `.ipynb` files (cleaned of cell outputs first via *Edit → Clear all outputs* in Colab) using the GitHub web UI: navigate to `github.com/exin-lti-upjv/incrt-geo-proteins/upload/main/notebooks` and drag-drop.

## Reproducibility notes

Each notebook uses Colab's free-tier or Pro+ environment. To run locally, install `requirements.txt` and adjust the Drive paths at the top of each notebook to local filesystem paths.

The notebooks **download all data at runtime** (Ensembl FASTA, UniProt Pfam mapping); nothing needs to be pre-staged.

A fixed random seed (`SEED=42`) is used throughout, but exact reproducibility requires also pinning the PyTorch / CUDA versions (see `requirements.txt`) and the Ensembl release (115).
