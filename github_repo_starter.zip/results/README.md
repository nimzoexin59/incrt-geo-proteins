# Pre-computed evaluation results

This directory contains the **JSON output files** produced by `scripts/allnight_eval.ipynb`. Reviewers can verify the numbers reported in the paper without re-running anything.

## Structure

```
results/
├── pfam_summaries/                  ← Pfam-50 linear-probe + light fine-tune
│   ├── v8_pfam.json                  example: {"linear_probe": {"test_acc": 0.6358, ...}, ...}
│   ├── v9_pfam.json                  also: multi-seed aggregates with mean ± std
│   ├── v10_pfam.json
│   ├── v11_pfam.json
│   ├── v9p_pfam.json
│   ├── v9_seed0_pfam.json            individual seed results for error bars
│   ├── v9_seed1_pfam.json
│   ├── v9_seed2_pfam.json
│   └── ...                           (similarly for v10, v11, v9')
│
└── architectural_diagnostics/        ← per-model: layer-wise alpha distribution, eff. rank, head similarity
    ├── v9_diag.json
    ├── v10_diag.json
    ├── v11_diag.json
    └── v9p_diag.json
```

## File format

Each `*_pfam.json` follows the schema:

```json
{
  "label": "v9_main",
  "checkpoint": "...",
  "architecture": {
    "layers": 4,
    "heads_per_layer": [207, 135, 1, 1],
    "total_params": 22700000,
    "d": 256
  },
  "n_train": 7172,
  "n_val": 876,
  "n_test": 876,
  "linear_probe": {
    "best_val_acc": 0.7591,
    "test_acc": 0.7603,
    "test_top5": 0.9272
  },
  "fine_tune": {
    "best_val_acc": 0.7011,
    "test_acc": 0.7078,
    "test_top5": 0.8959
  }
}
```

Each `*_diag.json` follows the schema:

```json
{
  "label": "v9_diag",
  "n_layers": 4,
  "heads_per_layer": [207, 135, 1, 1],
  "per_layer": [
    {
      "layer": 0,
      "n_heads": 207,
      "alpha_mean": 0.989,
      "alpha_min": 0.885,
      "alpha_max": 0.996,
      "effective_rank_Ma": 192.4,
      "mean_pairwise_cosine": 0.034,
      "abs_mean_pairwise_cosine": 0.058
    },
    ...
  ]
}
```

## Reproducing

To verify these numbers, run `scripts/allnight_eval.ipynb` on the pretrained checkpoints downloaded from Zenodo. Expect ~5 hours on a Colab Pro+ A100.
