# Evaluation scripts

This directory hosts evaluation pipelines that operate on the pretrained checkpoints produced by `notebooks/`.

| Notebook | Description | Time on Colab Pro+ A100 |
|----------|-------------|-------------------------|
| `allnight_eval.ipynb` | All-in-one evaluation pipeline: Pfam-50 re-evaluation of all 5 models, multi-seed runs (3 seeds × 4 models), CB513 secondary structure, architectural diagnostics. Per-job checkpointing — survives Colab disconnects. | ~5 hours |
| `v9p_pfam_rescue.ipynb` | OOM-resistant Pfam evaluation specifically for the multi-vertebrate v9' model (49M params, 6 layers): reduced batch size (8 instead of 32), explicit GPU cache management between phases. Self-contained: no dependence on other cells. | ~15 minutes |

## How to upload

The package zip ships this directory **empty**. Upload your local `.ipynb` files (cleaned of cell outputs) using the GitHub web UI.

## Outputs

Both scripts write JSON results to:
- `results/pfam_summaries/{model}_pfam.json` — Pfam-50 linear-probe and fine-tune accuracies
- `results/architectural_diagnostics/{model}_diag.json` — per-layer asymmetry index, effective rank, head similarity

These output files are version-controlled in the `results/` directory of this repository, so reviewers can verify the published numbers without re-running anything.
